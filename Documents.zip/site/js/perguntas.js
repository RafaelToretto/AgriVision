export const perguntas = [
    {
        enunciado: "Escolha o Enfoque da sua Agricultura de Precisão. Defina o principal objetivo da sua estratégia para garantir melhores resultados em sua produção agrícola.",
        alternativas: [
            {
                texto: "Aumentar a produção e maximizar a quantidade de colheitas e a eficiência geral.",
                afirmacao: [
                    "Tecnologia de Mapeamento; Utilizando drones e sensores para mapear a variabilidade do solo e otimizar o plantio.",
                    "Monitoramento de Crescimento; Acompanhar o desenvolvimento das culturas em tempo real para ajustes rápidos."
                ],
                proxima: 1,
            },
            {
                texto: "Reduzir impactos ambientais e focar em práticas que minimizam o impacto ambiental da sua produção agrícola.",
                afirmacao: [
                    "Controle de Erosão; Adotar métodos para prevenir a erosão do solo e preservar sua integridade.",
                    "Uso Eficiente de Recursos; Implementar técnicas de irrigação e fertilização que economizam água e insumos."
                ],
                proxima: 2,
            },
        ]
    },
    {
        enunciado: "Defina sua Prioridade para Agricultura de Precisão. Escolha a área principal que você deseja melhorar para atingir seus objetivos na agricultura.",
        alternativas: [
            {
                texto: "Melhoria da Eficiência Operacional, focando em tornar suas operações agrícolas mais eficientes e menos dispendiosas.",
                afirmacao: [
                    "Seleção de Cultivares; Escolher variedades de sementes adaptadas às condições locais para melhores resultados.",
                    "Controle de Qualidade; Utilizar tecnologias para monitorar a saúde e a qualidade das culturas durante o crescimento.",
                    "Otimização do Solo; Ajustar o manejo do solo para garantir a melhor condição para o desenvolvimento das plantas."
                ],
                proxima: 3,
            },
            {
                texto: "Aumento da Qualidade dos Produtos, priorizando técnicas que melhorem a qualidade e o valor dos seus produtos agrícolas.",
                afirmacao: [
                    "Sentiu mais facilidade em utilizar seus próprios recursos para escrever seu trabalho.",
                    "Achou que era muito mais fácil procurar por respostas utilizando alguns meios mais tradicionais mesmo que levasse mais tempo.",
                    "Sentiu um pouco de medo de quais dados pessoais seus a IA poderia utilizar e por isso prefere fazer suas coisas com pouca intromissão da tecnologia."
                ],
                proxima: 4,
            },
        ]
    },
    {
        enunciado: "Escolha o Objetivo Principal para sua Agricultura de Precisão. Determine qual aspecto da sua operação você deseja aprimorar para obter os melhores resultados.",
        alternativas: [
            {
                texto: "Gestão eficiente de recursos, focando em melhorar o uso de recursos para reduzir custos e desperdícios.",
                afirmacao: [
                    "Irrigação Precisa; Implementar sistemas de irrigação que atendem às necessidades exatas das plantas.",
                    "Aplicação Controlada de Insumos; Utilizar tecnologia para aplicar fertilizantes e defensivos de forma precisa e eficiente.",
                    "Redução de Desperdícios; Monitorar e ajustar práticas para minimizar o desperdício de recursos e insumos."
                ],
                proxima: 3,
            },
            {
                texto: "Maximização da rentabilidade, concentrando-se em aumentar a rentabilidade da sua produção através de estratégias eficazes.",
                afirmacao: [
                    "Análise de Custo-Benefício; Avaliar o retorno sobre investimento de diferentes tecnologias e práticas agrícolas.",
                    "Otimização de Preços; Ajustar a produção e a comercialização para obter o melhor preço de mercado para seus produtos.",
                    "Aumento da Produtividade; Adotar tecnologias que aumentem a quantidade e a qualidade das colheitas para maximizar a receita."
                ],
                proxima: 4,
            },
        ]
    },
    {
        enunciado: "Determine o Foco da sua Implementação de Agricultura de Precisão. Escolha a abordagem correta que pode transformar a sua operação agrícola.",
        alternativas: [
            {
                texto: "Redução de Custos, focando em reduzir os custos operacionais e melhorar a eficiência financeira.",
                afirmacao: [
                    "Manutenção Proativa; Realizar manutenção preditiva das máquinas para evitar falhas e custos inesperados.",
                    "Controle de Inventário; Gerenciar e controlar o uso de insumos para reduzir o desperdício e os custos."
                ],
                proxima: 5,
            },
            {
                texto: "Melhoria na gestão ambiental, priorizando práticas que promovem a sustentabilidade e a proteção ambiental.",
                afirmacao: [
                    "Uso Responsável de Produtos Químicos; Reduzir a aplicação de pesticidas e fertilizantes para minimizar impactos ambientais.",
                    "Conservação de Água; Adotar técnicas que economizam água e preservam recursos hídricos."
                ],
                proxima: 6,
            },
        ]
    },
    {
        enunciado: "Escolha o Enfoque Principal para sua Agricultura de Precisão. Decida qual aspecto da agricultura de precisão é mais relevante para o sucesso da sua operação.",
        alternativas: [
            {
                texto: "Aumento da Eficiência do Trabalho, concentrando-se em melhorar a produtividade e reduzir o tempo gasto em tarefas agrícolas.",
                afirmacao: [
                    "Automatização de Processos; Adotar tecnologias que automatizam tarefas, como plantio e colheita.",
                    "Gerenciamento de Tempo; Utilizar ferramentas para planejar e otimizar a execução das operações agrícolas."
                ],
                proxima: 5,
            },
            {
                texto: "Melhoria da saúde das culturas, priorizando técnicas que garantam o melhor desenvolvimento e saúde das suas plantas.",
                afirmacao: [
                    "Monitoramento de Nutrição; Utilizar sensores para verificar as necessidades nutricionais das plantas e ajustar a aplicação de fertilizantes.",
                    "Controle de Doenças e Pragas; Implementar sistemas para detectar e tratar problemas rapidamente."
                ],
                proxima: 6,
            },
        ]
    },
    {
        enunciado: "Determine o Principal Objetivo da sua Agricultura de Precisão. Escolher o foco principal ajudará a direcionar suas estratégias e investimentos em agricultura de precisão.",
        alternativas: [
            {
                texto: "Melhoria na rentabilidade, com foco em estratégias que aumentam a eficiência e os lucros da sua produção agrícola.",
                afirmacao: [
                    "Aumento de Rendimento; Adotar tecnologias que aumentam a produtividade das suas colheitas.",
                    "Análise de Mercado; Estudar o mercado para ajustar a produção de acordo com a demanda e maximizar os lucros."
                ],
                proxima: 7,
            },
            {
                texto: "Sustentabilidade ambiental, priorizando práticas que promovem a conservação dos recursos naturais e a sustentabilidade.",
                afirmacao: [
                    "Práticas de Agricultura Conservacionista; Implementar técnicas que preservam a estrutura do solo e evitam a erosão.",
                    "Eficiência Energética; Adotar tecnologias que economizam energia e reduzem o impacto ambiental."
                ],
                proxima: 7,
            },
        ]
    },
    {
        enunciado: "Escolha a Prioridade para a sua Agricultura de Precisão. Defina a prioridade que ajudará a melhorar os aspectos mais críticos da sua operação agrícola.",
        alternativas: [
            {
                texto: "Gestão de Recursos Naturais, focando na utilização e conservação dos recursos naturais de forma eficiente.",
                afirmacao: [
                    "Uso de Tecnologias de Irrigação; Implementar sistemas avançados que garantem a irrigação adequada e conservam água.",
                    "Controle de Nutrientes do Solo; Utilizar tecnologias para monitorar e ajustar a aplicação de nutrientes, evitando excessos."
                ],
                proxima: 7,
            },
            {
                texto: "Eficiência Econômica, priorizando estratégias que melhoram a eficiência econômica e a rentabilidade da operação.",
                afirmacao: [
                    "Otimização de Processos; Melhorar a eficiência dos processos agrícolas para reduzir custos e aumentar a produtividade.",
                    "Análise de Dados Financeiros; Avaliar dados financeiros para identificar oportunidades de redução de custos e aumento de lucro."
                ],
                proxima: 7,
            },
        ]
    },
    {
        enunciado: "Defina o Foco da sua Agricultura de Precisão. Escolha o foco certo para a sua agricultura de precisão para alcançar os melhores resultados possíveis.",
        alternativas: [
            {
                texto: "Inovação Tecnológica, concentrando-se em integrar novas tecnologias para melhorar a eficiência e a produção.",
                afirmacao: [
                    "Integração de Sistemas Avançados; Utilizar sistemas de GPS, drones e sensores para monitorar e gerenciar suas operações agrícolas.",
                    "Automação de Máquinas; Adotar equipamentos automatizados que aumentam a precisão e reduzem o trabalho manual."